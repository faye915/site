#include <IRremote.h>
#include <FastLED.h>
#include "carMotors.h"
#include "LightSensor.h"
#include "UltraSonic.h"

#define PIN_RBGLED 4
#define NUM_LEDS 1
CRGB leds[NUM_LEDS];// Tableau pour contrôler la LED
IRrecv irrecv(9); // Récepteur infrarouge sur broche 9
decode_results results;
CarMotors engine;
LightSensor sensors(A0, A1, A2, 600); 
UltraSonic eye; 

bool isStarted = false;
int headAngle = 90;
int headStep = 25; 

void setup() {
  engine.init(85); 
  sensors.init();
  eye.init();
  irrecv.enableIRIn();// Active le récepteur infrarouge
  FastLED.addLeds<NEOPIXEL, PIN_RBGLED>(leds, NUM_LEDS);
  leds[0] = CRGB::Red; // LED rouge au démarrage
  FastLED.show();
}

void loop() {
  // Regarde si il y a signal infrarouge 
  if (irrecv.decode(&results)) {
    if ((results.value & 0xFF) == 0x02 || results.value == 0xFF02FD) {
      isStarted = true;
      leds[0] = CRGB::Green;
      FastLED.show();
    }
    irrecv.resume();
  }

  if (isStarted) {
    // BALAYAGE TRÈS LARGE : de 20° à 160° pour couvrir tout l'avant
    eye.turnHead(headAngle);
    headAngle += headStep;
    if (headAngle >= 160 || headAngle <= 20) headStep = -headStep;

    float distance = eye.getDistance();
    bool isCliff = (sensors.isLeftBlack() || sensors.isCenterBlack() || sensors.isRightBlack());//au moins un capteur voit du noir
    bool isWall = (distance > 0 && distance < 180); // Sensibilité 

    if (isCliff || isWall) {
      //  mur détecté
      engine.drive(-0.8, -0.8); 
      delay(400);

      // 2. TOURNER À GAUCHE 
      // On pousse la roue DROITE vers l'avant (1.0) et la GAUCHE vers l'arrière (-0.6)
      engine.drive(1.0, -0.6); 
      delay(600);
    } 
    else {
      engine.goForward(); 
    }
  }
}