#ifndef ULTRASONIC_H
#define ULTRASONIC_H
#include <Arduino.h>
#include <Servo.h>
class UltraSonic {
  private:
    Servo myServo;
  public:
    UltraSonic();
    void init();
    float getDistance();
    void turnHead(unsigned int angle);
};
#endif