#ifndef CARMOTORS_H
#define CARMOTORS_H
#include <Arduino.h>

#define PIN_Motor_PWMA 5
#define PIN_Motor_PWMB 6
#define PIN_Motor_BIN_1 8
#define PIN_Motor_AIN_1 7
#define PIN_Motor_STBY 3

class CarMotors {
private:
  uint8_t currentSpeed = 0;
  void enableDriver(bool enable) { digitalWrite(PIN_Motor_STBY, enable ? HIGH : LOW); }

public:
  void init(uint8_t p_speed) {
    pinMode(PIN_Motor_PWMA, OUTPUT); pinMode(PIN_Motor_PWMB, OUTPUT);
    pinMode(PIN_Motor_AIN_1, OUTPUT); pinMode(PIN_Motor_BIN_1, OUTPUT);
    pinMode(PIN_Motor_STBY, OUTPUT);
    setSpeed(p_speed); stop();  // Initialise la vitesse et arrête les moteurs
  }
  void setSpeed(uint8_t p_speed) { currentSpeed = p_speed; }
  void goForward() {
    enableDriver(true); 
    digitalWrite(PIN_Motor_AIN_1, HIGH);// Moteur A : avant
     digitalWrite(PIN_Motor_BIN_1, HIGH);
    analogWrite(PIN_Motor_PWMA, currentSpeed); 
    analogWrite(PIN_Motor_PWMB, currentSpeed);// Vitesse moteur B
  }
  void drive(float leftCoef, float rightCoef) {
    enableDriver(true);

    // Détermine le sens de rotation pour chaque moteur
    digitalWrite(PIN_Motor_AIN_1, (leftCoef >= 0) ? HIGH : LOW);
    digitalWrite(PIN_Motor_BIN_1, (rightCoef >= 0) ? HIGH : LOW);

    analogWrite(PIN_Motor_PWMA, (int)(currentSpeed * abs(leftCoef)));
    analogWrite(PIN_Motor_PWMB, (int)(currentSpeed * abs(rightCoef)));
  }
  void stop() { analogWrite(PIN_Motor_PWMA, 0); analogWrite(PIN_Motor_PWMB, 0); enableDriver(false); }
};
#endif
