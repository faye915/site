#include "UltraSonic.h"

// Constructeur de la classe UltraSonic
UltraSonic::UltraSonic() {}

void UltraSonic::init() {
  pinMode(12, INPUT); 
  pinMode(13, OUTPUT); 
  myServo.attach(10, 500, 2400); 
  myServo.write(90); 
}

float UltraSonic::getDistance() {
  digitalWrite(13, LOW); // état signal
  delayMicroseconds(2);
  digitalWrite(13, HIGH); 
  delayMicroseconds(10);
  digitalWrite(13, LOW);
  
  // pause 15ms pour un scan ultra-rapide
  long duration = pulseIn(12, HIGH, 15000); 
  if (duration == 0) return 999;
  return duration / 5.8f; 
}
// Méthode pour tourner la tête du capteur
void UltraSonic::turnHead(unsigned int angle) {
  myServo.write(angle); 
  
}