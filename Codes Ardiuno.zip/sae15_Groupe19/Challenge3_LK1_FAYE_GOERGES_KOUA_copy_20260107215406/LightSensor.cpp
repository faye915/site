#include "LightSensor.h"

LightSensor::LightSensor(uint8_t pL, uint8_t pC, uint8_t pR, int thresh) 
    : pinL(pL), pinC(pC), pinR(pR), threshold(thresh) {}
// Fonction d'initialisation des capteurs
void LightSensor::init() {
    pinMode(pinL, INPUT); pinMode(pinC, INPUT); pinMode(pinR, INPUT);// Configure les broches
}

bool LightSensor::isLeftBlack() { return analogRead(pinL) > threshold; }// Vérifie si le capteur GAUCHE voit du noir
bool LightSensor::isCenterBlack() { return analogRead(pinC) > threshold; }
bool LightSensor::isRightBlack() { return analogRead(pinR) > threshold; }