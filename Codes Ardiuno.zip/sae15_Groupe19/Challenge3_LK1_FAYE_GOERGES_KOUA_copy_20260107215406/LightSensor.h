#ifndef LIGHTSENSOR_H
#define LIGHTSENSOR_H
#include <Arduino.h>
class LightSensor {
private:
    uint8_t pinL, pinC, pinR;// Broche
    int threshold; // Seuil
public:
    LightSensor(uint8_t pL, uint8_t pC, uint8_t pR, int thresh);
    void init();
    bool isLeftBlack();
    bool isCenterBlack(); 
    bool isRightBlack(); // Retournent vrai si la ligne noire est détectée
};
#endif