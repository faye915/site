#include "LineDriver.h"
// paramètre 
LineDriver::LineDriver(CarMotors& m, LightSensor& s) : motors(m), sensors(s) {}

// Récupère l'état de chaque capteur
void LineDriver::follow() {
    bool L = sensors.isLeftBlack();
    bool C = sensors.isCenterBlack();
    bool R = sensors.isRightBlack();

    // Si AU MOINS UN capteur voit du noir
    if (L || C || R) {
        motors.stop(); 
    } 
}