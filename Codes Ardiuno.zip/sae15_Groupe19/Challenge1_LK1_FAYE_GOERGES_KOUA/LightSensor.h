#ifndef LIGHTSENSOR_H
#define LIGHTSENSOR_H
#include <Arduino.h>

class LightSensor {
private:
    uint8_t pinL, pinC, pinR;
    int threshold;
public:
    LightSensor(uint8_t pL, uint8_t pC, uint8_t pR, int thresh);
    void init();
    //  Chacune retourne vrai si le capteur voit du noir.
    bool isLeftBlack();
    bool isCenterBlack();
    bool isRightBlack();
    bool isIntersection();
};
#endif