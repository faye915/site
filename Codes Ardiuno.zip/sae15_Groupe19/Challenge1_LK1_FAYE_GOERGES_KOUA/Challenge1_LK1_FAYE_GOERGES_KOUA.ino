#include <FastLED.h>
#include "carMotors.h"
#include "LightSensor.h"
#include "LedIndicator.h"
#include "LineDriver.h"

#define PIN_RBGLED 4
#define NUM_LEDS 1
CRGB leds[NUM_LEDS];

CarMotors engine;
// Seuil abaissé à 600 pour mieux détecter le noir
LightSensor sensors(A0, A1, A2, 600); 
LineDriver pilot(engine, sensors);

int ligneCompteur = 0;
bool intersectionDetected = false;
bool isStarted = false;

void setup() {
  // Vitesse abaissée à 100 pour ne pas rater les virages
  engine.init(100); 
  sensors.init();
  FastLED.addLeds<NEOPIXEL, PIN_RBGLED>(leds, NUM_LEDS);
  FastLED.setBrightness(55);

 //  SÉQUENCE DE DÉMARRAGE
  leds[0] = CRGB::Red;    FastLED.show(); delay(1000); 
  leds[0] = CRGB::Orange; FastLED.show(); delay(1000); 
  leds[0] = CRGB::Green;  FastLED.show(); delay(1000); 
  
  isStarted = true;
}

void loop() {
  if (!isStarted) return;

  if (sensors.isIntersection()) {
    if (!intersectionDetected) {   // Première détectio
      ligneCompteur++; // On compte une ligne de plus
      intersectionDetected = true;
    }
  } else {
    intersectionDetected = false;
  }

  //  COULEURS 
  if (ligneCompteur >= 7) {   //  FIN DE COURSE : 7 lignes atteintes
    engine.stop();
    leds[0] = CRGB::Yellow;  // Jaune
    FastLED.show();
    while(1); 
  } 
  else if (ligneCompteur >= 5) {
    leds[0] = CRGB(255, 80, 0); // Orange
  } 
  else if (ligneCompteur >= 3) {
    leds[0] = CRGB::Blue;       // Bleu
  } 
  else if (ligneCompteur >= 1) {
    leds[0] = CRGB::Green;      // Vert
  }
  FastLED.show();

  pilot.follow();
}