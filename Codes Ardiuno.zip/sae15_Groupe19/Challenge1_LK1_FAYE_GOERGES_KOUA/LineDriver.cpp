#include "LineDriver.h"

LineDriver::LineDriver(CarMotors& m, LightSensor& s) : motors(m), sensors(s) {}

// On lit l'état du sol sous les 3 capteurs
void LineDriver::follow() {
    bool L = sensors.isLeftBlack();
    bool C = sensors.isCenterBlack();
    bool R = sensors.isRightBlack();

    //  Quand on voit une intersection 
    if (L && C && R) {
        motors.goForward(); 
    } 
    else if (C) {
        motors.goForward(); 
    } 
    else if (L) {
        // Pivot Gauche : 
        motors.drive(-0.7, 1.0); 
    } 
    else if (R) {
        // Pivot Droit : la roue droite recule 
        motors.drive(1.0, -0.7); 
    }
    else {
        // Si on perd la ligne, on s'arrête 
        motors.stop();
    }
}