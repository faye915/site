#ifndef LINEDRIVER_H
#define LINEDRIVER_H

#include "carMotors.h"
#include "LightSensor.h"

class LineDriver {
private:
    CarMotors& motors;
    LightSensor& sensors;

public:
    LineDriver(CarMotors& m, LightSensor& s);
    void follow();
};

#endif