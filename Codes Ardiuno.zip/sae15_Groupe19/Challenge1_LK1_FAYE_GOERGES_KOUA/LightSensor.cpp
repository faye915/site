#include "LightSensor.h"

LightSensor::LightSensor(uint8_t pL, uint8_t pC, uint8_t pR, int thresh) 
    : pinL(pL), pinC(pC), pinR(pR), threshold(thresh) {}

void LightSensor::init() {
    pinMode(pinL, INPUT);
    pinMode(pinC, INPUT);
    pinMode(pinR, INPUT);
}

bool LightSensor::isLeftBlack() { return analogRead(pinL) > threshold; } //  Lit le capteur gauche, compare au seuil.Retourne vrai si la valeur lue est supérieure au seuil.
bool LightSensor::isCenterBlack() { return analogRead(pinC) > threshold; }
bool LightSensor::isRightBlack() { return analogRead(pinR) > threshold; }
bool LightSensor::isIntersection() { return isLeftBlack() && isCenterBlack() && isRightBlack(); } //  Détecte une intersection : quand les trois capteurs voient noir