#ifndef LEDINDICATOR_H
#define LEDINDICATOR_H

#include <FastLED.h>

class LedIndicator {
private:
    CRGB* leds;
    int numLeds;

public:
    LedIndicator(CRGB* pLeds, int count) : leds(pLeds), numLeds(count) {}

    void setColor(CRGB color) { 
        fill_solid(leds, numLeds, color); 
        FastLED.show(); 
    }
    
    
};

#endif