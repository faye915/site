#include "UltraSonic.h"
// Constructeur de la classe UltraSonic
UltraSonic::UltraSonic() {}

// Méthode d'initialisation du capteur ultrasonique et du servo
void UltraSonic::init() {
  pinMode(echo_pin, INPUT);    
  pinMode(trig_pin, OUTPUT);  
  myServo.attach(servo_pin, 500, 2400); // Initialisation du servo
  turnHead(90); // // Positionne le servo à 90° ]
}
// Méthode pour mesurer la distance en millimètres
float UltraSonic::getDistance() {
  digitalWrite(trig_pin, LOW); // Assure un état bas stable sur la broche  
  delayMicroseconds(2);
  digitalWrite(trig_pin, HIGH);  
  delayMicroseconds(10);
  digitalWrite(trig_pin, LOW);   
  
  // Calcul de la distance en millimètres 
  float d = pulseIn(echo_pin, HIGH) / 5.8f; // Formule : durée (µs) / 5.8 = distance (mm)  
  return d;
}

void UltraSonic::turnHead(unsigned int angle) {
  myServo.attach(servo_pin);
  myServo.write(angle); 
  delay(450);
  myServo.detach();
}