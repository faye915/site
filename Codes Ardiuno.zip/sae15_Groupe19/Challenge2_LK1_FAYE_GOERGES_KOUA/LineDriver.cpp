// On importe le fichier qui gère le suivi de ligne
#include "LineDriver.h"

LineDriver::LineDriver(CarMotors& m, LightSensor& s) : motors(m), sensors(s) {}

// Fonction principale pour suivre la ligne
void LineDriver::follow() {
    bool L = sensors.isLeftBlack(); // Check si le capteur de gauche voit  la ligne noire, même  logique pour les autres 
    bool C = sensors.isCenterBlack();
    bool R = sensors.isRightBlack();

    // Logique de suivi de ligne
    if (L && C && R) {
        motors.goForward(); 
    } 
    else if (C) {
        motors.goForward(); 
    } 
    else if (L) {
        motors.drive(-0.7, 1.0); // ralentit la roue gauche et accélère la droite pour dévier
    } 
    else if (R) {
        motors.drive(1.0, -0.7); // même logique 
    }
    else {
        motors.stop();
    }
}