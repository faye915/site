#include <IRremote.h>
#include <FastLED.h>
#include "carMotors.h"
#include "LightSensor.h"
#include "LineDriver.h"
#include "UltraSonic.h"

// Configuration LED RBG
#define PIN_RBGLED 4
#define NUM_LEDS 1
CRGB leds[NUM_LEDS]; // Tableau pour stocker les couleurs des LEDs

// Objets pour les composants
IRrecv irrecv(9); 
decode_results results;
CarMotors engine;
LightSensor sensors(A0, A1, A2, 600); // Seuil de 600
LineDriver pilot(engine, sensors);
UltraSonic eye; // Capteur ultrasonique avec servo pour orientation
bool isStarted = false;

void setup() {
  engine.init(100); // Vitesse max initiale 100
  sensors.init();
  eye.init();      // Activation du récepteur infra
  irrecv.enableIRIn();
  
  FastLED.addLeds<NEOPIXEL, PIN_RBGLED>(leds, NUM_LEDS);
  FastLED.setBrightness(55);
  
  // ÉTAT INITIAL : LED ROuge (En attente du signal OK de la télécommande)
  leds[0] = CRGB::Orange; 
  FastLED.show();// Met à jour la LED avec la couleur définie
}

void loop() {
  // 1. Détection de la télécommande pour démarrer
  if (irrecv.decode(&results)) {
    if ((results.value & 0xFF) == 0x02 || results.value == 0xFF02FD) {
      isStarted = true;
    }
    irrecv.resume(); // Prépare le récepteur pour le prochain signal
  }

  if (isStarted) {
    // 2. Mesure de la distance avec le capteur ultrason
    float distance = eye.getDistance();

    //  CHALLENGE 2 : Couleurs et Vitesse
    if (distance > 0 && distance < 150) {
        // Trop proche  : LED Rouge et Arrêt
        leds[0] = CRGB::Red; 
        engine.setSpeed(0); 
    } 
    else if (distance > 0 && distance < 350) {
        // Un obstacle détecté  :   La LED Rouge et Ralentissement/stop
        leds[0] = CRGB::Red; 
        engine.setSpeed(65); 
    } 
    else {
        // Route libre : LED Verte et Vitesse normale 
        leds[0] = CRGB::Green; 
        engine.setSpeed(100); 
    }
    FastLED.show();// Met à jour la LED

    // Suivi de ligne
    pilot.follow();
  }
}