#ifndef ULTRASONIC_H
#define ULTRASONIC_H

#include <Arduino.h>
#include <Servo.h>// Bibliothèque pour contrôler les servomoteurs

class UltraSonic {
  private:
    const int servo_pin = 10; // Broche pour contrôler le servomoteur 
    const int echo_pin = 12;  // Broche pour lire le signal d'écho du capteur ultraso
    const int trig_pin = 13;  // Broche pour envoyer le signal de déclenchement 
    Servo myServo;

  public:
    UltraSonic();
    void init();
    float getDistance();// Méthode pour obtenir la distance mesurée
    void turnHead(unsigned int angle);// Méthode pour tourner la tête du capteur
};

#endif