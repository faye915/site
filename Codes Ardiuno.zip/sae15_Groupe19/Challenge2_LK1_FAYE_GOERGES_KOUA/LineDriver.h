// n pour éviter d'inclure ce fichier plusieurs fois
#ifndef LINEDRIVER_H
#define LINEDRIVER_H

#include "carMotors.h"
#include "LightSensor.h"

class LineDriver {
private:
    CarMotors& motors;
    LightSensor& sensors; // Prend les objets moteurs et capteurs en paramètres

public:
    LineDriver(CarMotors& m, LightSensor& s);
    void follow(); 
};

#endif