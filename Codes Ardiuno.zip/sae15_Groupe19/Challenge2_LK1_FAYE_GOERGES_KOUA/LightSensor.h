#ifndef LIGHTSENSOR_H
#define LIGHTSENSOR_H
#include <Arduino.h>

class LightSensor {
private:
    uint8_t pinL, pinC, pinR;// Numéro de la broche pour le capteur 
    int threshold;// Valeur limite pour décider si c'est noir ou blanc

public:
    LightSensor(uint8_t pL, uint8_t pC, uint8_t pR, int thresh);
    void init();
    bool isLeftBlack(); // Vérifie si le capteur gauche voit du noir
    bool isCenterBlack();
    bool isRightBlack();
    bool isIntersection(); // Vérifie si c'est une intersection (les 3 capteurs voient du noir)
};
#endif // Fin de la protection contre les inclusions multiples