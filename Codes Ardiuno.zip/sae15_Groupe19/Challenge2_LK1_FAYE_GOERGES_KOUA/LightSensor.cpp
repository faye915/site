#include "LightSensor.h"

// Reçoit les numéros des broches pour les capteurs gauche, centre, droit et la valeur du seuil
LightSensor::LightSensor(uint8_t pL, uint8_t pC, uint8_t pR, int thresh) 
    : pinL(pL), pinC(pC), pinR(pR), threshold(thresh) {}

// Fonction pour initialiser les capteurs

void LightSensor::init() { 
    pinMode(pinL, INPUT);
    pinMode(pinC, INPUT);
    pinMode(pinR, INPUT);
}

bool LightSensor::isLeftBlack() { return analogRead(pinL) > threshold; }// Vérifie si le capteur gauche voit du noir renvoie vrai si la valeur lue est plus grande que le seuil
bool LightSensor::isCenterBlack() { return analogRead(pinC) > threshold; }
bool LightSensor::isRightBlack() { return analogRead(pinR) > threshold; }
bool LightSensor::isIntersection() { return isLeftBlack() && isCenterBlack() && isRightBlack(); }// Si les trois voient du noir → c’est une intersection
