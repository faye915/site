#ifndef CARMOTORS_H
#define CARMOTORS_H

#include <Arduino.h>

#define PIN_Motor_PWMA 5
#define PIN_Motor_PWMB 6
#define PIN_Motor_BIN_1 8
#define PIN_Motor_AIN_1 7
#define PIN_Motor_STBY 3

class CarMotors {
private:
  uint8_t currentSpeed = 0;   // vitesse courante
  bool isMoving = false;      // état du mouvement robot

  void enableDriver(bool enable) {
    digitalWrite(PIN_Motor_STBY, enable ? HIGH : LOW);
  }

public:
  // initialisation des ports pour commander les moteurs
  void init(uint8_t p_speed) {

    // Configure toutes les broches en sortie

    pinMode(PIN_Motor_PWMA, OUTPUT);
    pinMode(PIN_Motor_PWMB, OUTPUT);
    pinMode(PIN_Motor_AIN_1, OUTPUT);
    pinMode(PIN_Motor_BIN_1, OUTPUT);
    pinMode(PIN_Motor_STBY, OUTPUT);

    setSpeed(p_speed);
    stop(); // Assure que le robot est à l'arrêt au démarrage
  }

  // réglage de la vitesse de rotation
  void setSpeed(uint8_t p_speed) { currentSpeed = p_speed; }

  // fait avancer la voiture
  void goForward() {
    enableDriver(true);
    digitalWrite(PIN_Motor_AIN_1, HIGH);
    digitalWrite(PIN_Motor_BIN_1, HIGH);
    analogWrite(PIN_Motor_PWMA, currentSpeed);
    analogWrite(PIN_Motor_PWMB, currentSpeed);
    isMoving = true;
  }

  // fait reculer la voiture
  void goBackward() {
    enableDriver(true);
    digitalWrite(PIN_Motor_AIN_1, LOW);
    digitalWrite(PIN_Motor_BIN_1, LOW);
    analogWrite(PIN_Motor_PWMA, currentSpeed);
    analogWrite(PIN_Motor_PWMB, currentSpeed);
    isMoving = true;
  }

  // tourne sur place vers la gauche
  void turnLeft() {
    enableDriver(true);
    digitalWrite(PIN_Motor_AIN_1, LOW);
    digitalWrite(PIN_Motor_BIN_1, HIGH);
    analogWrite(PIN_Motor_PWMA, currentSpeed);
    analogWrite(PIN_Motor_PWMB, currentSpeed);
    isMoving = true;
  }

  // tourne sur place vers la droite
  void turnRight() {
    enableDriver(true);
    digitalWrite(PIN_Motor_AIN_1, HIGH);
    digitalWrite(PIN_Motor_BIN_1, LOW);
    analogWrite(PIN_Motor_PWMA, currentSpeed);
    analogWrite(PIN_Motor_PWMB, currentSpeed);
    isMoving = true;
  }

  // Contrôle différentiel des moteurs pour virages progressif
  void drive(float leftCoef, float rightCoef) {
    enableDriver(true);

// Limite les coefficients entre -1.0 et 1.0
    leftCoef  = constrain(leftCoef,  -1.0, 1.0);
    rightCoef = constrain(rightCoef, -1.0, 1.0);

    int leftSpeed  = (int)(currentSpeed * abs(leftCoef));
    int rightSpeed = (int)(currentSpeed * abs(rightCoef));

  // Détermine le sens de rotation de chaque moteur 
    // sens gauche
    digitalWrite(PIN_Motor_AIN_1, (leftCoef  >= 0) ? HIGH : LOW);// sens gauche
    // sens droite
    digitalWrite(PIN_Motor_BIN_1, (rightCoef >= 0) ? HIGH : LOW);

    
    // Applique les vitesses PWM calculées
    analogWrite(PIN_Motor_PWMA, leftSpeed);
    analogWrite(PIN_Motor_PWMB, rightSpeed);

    isMoving = (leftSpeed > 0 || rightSpeed > 0);
  }

  // arrêt total
  void stop() {
    analogWrite(PIN_Motor_PWMA, 0);
    analogWrite(PIN_Motor_PWMB, 0);
    enableDriver(false);

    isMoving = false;// Met à jour l'état
  }
// Retourne l'état de mouvement du robot
  bool getIsMoving() { return isMoving; }
};

#endif  